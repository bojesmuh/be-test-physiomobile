@extends('frontend.layouts.front')

@section('content')
    <div style="padding: 1rem;">
        <h2>Selamat datang di halaman Tentang Kami</h2>
        <p>Ini adalah konten utama dari website.</p>
    </div>
@endsection